# .NET_sdk

[![Join the chat at https://gitter.im/supremainc/sfm-sdk-dotnet](https://badges.gitter.im/supremainc/sfm-sdk-dotnet.svg)](https://gitter.im/supremainc/sfm-sdk-dotnet?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

SFM_SDK_NET.dll is a wrapping class library of the SFM_SDK.dll which is written based on C.
SFM_SDK_NET.dll is currently under-development (BETA).
There are some bugs or wrong wrapping codes can be existed.

Release Notes: https://github.com/supremainc/.NET_sdk/releases

