package fr.coppernic.sample.fingerprint.ui;


import android.app.Fragment;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import fr.coppernic.sample.fingerprint.BuildConfig;
import fr.coppernic.sample.fingerprint.R;
import fr.coppernic.sdk.fingerprint.RxReader;
import fr.coppernic.sdk.fingerprint.ui.FpDialogManager;
import fr.coppernic.sdk.utils.debug.L;

/**
 * A simple {@link Fragment} subclass.
 */
public class FingerPrintFragment extends Fragment {

    public static final String TAG = "FingerPrintFragment";
    @BindView(R.id.btn_record)
    Button btnRecord;
    @BindView(R.id.imgResult)
    ImageView result;
    private final FpDialogManager.FingerPrintListener listener = new FpDialogManager.FingerPrintListener() {
        @Override
        public void onFingerPrintImageAvailable(Bitmap bmp) {
            result.setImageDrawable(new BitmapDrawable(getResources(), bmp));
        }
    };
    private FpDialogManager fpDialogManager;
    private RxReader reader;
    private Unbinder unbinder;


    public FingerPrintFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_finger_print, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        unbinder = ButterKnife.bind(this, view);

        if (reader != null) {
            Log.d(TAG, "Create dialog manager");
            fpDialogManager = new FpDialogManager(getActivity(), reader);
        } else {
            Log.w(TAG, "No dialog manager");
        }

        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {

        if (fpDialogManager != null) {
            fpDialogManager.dismiss();
        }

        super.onStop();
    }

    @OnClick(R.id.btn_record)
    public void record() {
        if (fpDialogManager != null) {
            fpDialogManager.show(listener);
        } else {
            Toast.makeText(getActivity(), "No dialog", Toast.LENGTH_SHORT).show();
        }

    }

    public void setReader(RxReader reader) {
        L.m(TAG, BuildConfig.DEBUG);
        this.reader = reader;
        if (fpDialogManager == null && getActivity() != null) {
            Log.d(TAG, "Create dialog manager");
            fpDialogManager = new FpDialogManager(getActivity(), reader);
        }
    }

}
