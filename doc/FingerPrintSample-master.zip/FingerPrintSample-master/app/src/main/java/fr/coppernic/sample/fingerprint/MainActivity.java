package fr.coppernic.sample.fingerprint;

import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import java.util.Arrays;
import java.util.List;

import fr.coppernic.sample.fingerprint.settings.SettingsActivity;
import fr.coppernic.sample.fingerprint.ui.FingerPrintFragment;
import fr.coppernic.sample.fingerprint.ui.NoReaderFragment;
import fr.coppernic.sdk.fingerprint.RxReader;
import fr.coppernic.sdk.fingerprint.Type;
import fr.coppernic.sdk.power.PowerManager;
import fr.coppernic.sdk.power.api.PowerListener;
import fr.coppernic.sdk.power.api.peripheral.Peripheral;
import fr.coppernic.sdk.power.impl.cone.ConePeripheral;
import fr.coppernic.sdk.power.impl.idplatform.IdPlatformPeripheral;
import fr.coppernic.sdk.ui.progress.spot.SpotsDialog;
import fr.coppernic.sdk.utils.core.CpcResult.RESULT;
import fr.coppernic.sdk.utils.debug.L;
import fr.coppernic.sdk.utils.helpers.CpcOs;

import static fr.coppernic.sample.fingerprint.BuildConfig.DEBUG;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private FragmentManager fragmentManager;
    private Dialog powerDialog;
    private final PowerListener powerListener = new PowerListener() {
        @Override
        public void onPowerUp(RESULT res, Peripheral peripheral) {
            L.m(TAG, DEBUG);
            if (res == RESULT.OK) {
                RxReader reader = buildReader();
                if (reader != null) {
                    displayFragment(getFingerPrintFragment(reader), FingerPrintFragment.TAG);
                } else {
                    displayFragment(getNoReaderFragment(), NoReaderFragment.TAG);
                }
            } else {
                displayFragment(getNoReaderFragment(), NoReaderFragment.TAG);
            }
        }

        @Override
        public void onPowerDown(RESULT res, Peripheral peripheral) {

        }
    };
    private Peripheral peripheral;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentManager = getFragmentManager();
        //powerModule = new PowerModule(this, powerUtilsNotifier);
        peripheral = getPowerPeripheral();
        PowerManager.get().registerListener(powerListener);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.action_setting:
                Intent intent = new Intent(this, SettingsActivity.class);
                this.startActivity(intent);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        Log.d(TAG, "onStart");
        super.onStart();
        startPowering();
    }

    @Override
    protected void onStop() {
        Log.d(TAG, "onStop");
        removeFragments(Arrays.asList(FingerPrintFragment.TAG, NoReaderFragment.TAG));
        stopPowering();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy");
        PowerManager.get().unregisterAll();
        PowerManager.get().releaseResources();
        super.onDestroy();
    }

    private void startPowering() {
        powerDialog = new SpotsDialog(this, R.style.PowerDialog);
        powerDialog.show();
        peripheral.on(this);
    }

    private void stopPowering() {
        if (powerDialog != null) {
            powerDialog.dismiss();
        }
        peripheral.off(this);
    }

    private Fragment getFingerPrintFragment(RxReader reader) {
        FingerPrintFragment f = (FingerPrintFragment) fragmentManager.findFragmentByTag(FingerPrintFragment.TAG);
        if (f == null) {
            f = new FingerPrintFragment();
        }
        f.setReader(reader);
        return f;
    }

    private Fragment getNoReaderFragment() {
        Fragment f = fragmentManager.findFragmentByTag(NoReaderFragment.TAG);
        if (f == null) {
            f = new NoReaderFragment();
        }
        return f;
    }

    private void displayFragment(Fragment f, String tag) {
        if (powerDialog != null) {
            powerDialog.dismiss();
        }
        fragmentManager.beginTransaction()
            .replace(R.id.fragment_container, f, tag)
            .commit();
    }

    private void removeFragments(List<String> tags) {
        if (tags.isEmpty()) {
            return;
        }

        FragmentTransaction transaction = fragmentManager.beginTransaction();
        for (String tag : tags) {
            Fragment f = fragmentManager.findFragmentByTag(tag);
            if (f != null) {
                transaction.remove(f);
            }
        }
        transaction.commitAllowingStateLoss();
    }

    private RxReader buildReader() {
        return new RxReader.Builder().withType(getTypeFromPreferences()).build(this);
    }

    private Type getTypeFromPreferences() {
        final SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
        String typeStr = pref.getString("key_reader_type", "NONE");
        return Type.fromString(typeStr);
    }

    private Peripheral getPowerPeripheral() {
        if (CpcOs.isCone()) {
            return ConePeripheral.FP_IB_COLOMBO_USB;
        } else if (CpcOs.isIdPlatform()) {
            return IdPlatformPeripheral.FINGERPRINT;
        }
        return null;
    }
}
