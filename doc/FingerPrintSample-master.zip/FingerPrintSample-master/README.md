# FingerPrintSample
Sample to demonstrate simple fingerprint acquisition

## Prerequisites

CpcFingerprintService and CpcSystemServices shall be installed on your device.
Please install the last version available on FDroid already installed
 on your device.


## Sample

 * Go to setting screen
 * Choose the reader that is installed on your device
 * You can Click on record
 * Put your finger on reader

![Sample screen][5]

## Set up

### build.gradle

```groovy
repositories {
    mavenCentral()
    jcenter()
    maven { url 'https://artifactory.coppernic.fr/artifactory/libs-release' }
}


dependencies {
// [...]
    compile(group: 'fr.coppernic.sdk.cpcutils', name: 'CpcUtilsLib', version: '6.11.0', ext: 'aar') {
        transitive = true
    }
    compile(group: 'fr.coppernic.sdk.fingerprint', name: 'CpcFingerPrint', version: '0.3.0', ext: 'aar') {
        transitive = true
    }
    compile(group: 'fr.coppernic.sdk.core', name: 'CpcCore', version: '1.1.1', ext: 'aar') {
        transitive = true
    }
    compile(group: 'fr.coppernic.sdk.ui', name: 'CpcUi', version: '1.0.1', ext: 'aar') {
        transitive = true
    }

// [...]
}

```

### Power management

 * Create a power listener

```java
private final PowerListener powerListener = new PowerListener() {
    @Override
    public void onPowerUp(RESULT res, Peripheral peripheral) {
        if (res == RESULT.OK) {
            //Peripheral is on
        } else {
            //Peripehral is undefined
        }
    }

    @Override
    public void onPowerDown(RESULT res, Peripheral peripheral) {
        //Peripehral is off
    }
};
```

 * Register the listener

```java
@Override
protected void onCreate(Bundle savedInstanceState) {
    PowerManager.get().registerListener(powerListener);
}
```

 * Select a peripheral according to device and power it on

```java
if (CpcOs.isCone()) {
    peripheral = ConePeripheral.FP_IB_COLOMBO_USB;
} else if (CpcOs.isIdPlatform()) {
    peripheral = IdPlatformPeripheral.FINGERPRINT;
}

peripheral.on(context);
//The the listener will be called with the result
```

 * Power off when you are done

```java
peripheral.off(context);
//The the listener will be called with the result
```

 * release resources

```java
@Override
protected void onDestroy() {
    PowerManager.get().unregisterAll();
    PowerManager.get().releaseResources();
    super.onDestroy();
}
```

### Finger print dialog

 * Create a listener

```java
private final FpDialogManager.FingerPrintListener listener = new FpDialogManager.FingerPrintListener() {
    @Override
    public void onFingerPrintImageAvailable(Bitmap bmp) {
        //do something with bitmap
    }
};
```

 * Create a finger print dialog

```java
Type type = Type.NONE;//Choose the good finger print type
RxReader reader = new RxReader.Builder().withType(type).build(this);
FpDialogManager fpDialogManager = new FpDialogManager(getActivity(), reader);
```

 * Record finger print

```java
fpDialogManager.show(listener);
//listener will be called with the bitmap if any
```

### Finger Print API

 * Create reader

```java
Type type = Type.NONE;//Choose the good finger print type
RxReader reader = new RxReader.Builder().withType(type).build(this);
```

 * Subscribe to finger print observable

```java
private final Action closeReader = new Action() {
    @Override
    public void run() throws Exception {
        if (reader != null) {
            reader.close();
        }
    }
};

private final Observer<Print> fingerObserver = new Observer<Print>() {
        @Override
        public void onSubscribe(@io.reactivex.annotations.NonNull Disposable d) {
            // Register a disposable to be able to cancel capture
            disposable = d;
        }

        @Override
        public void onNext(@io.reactivex.annotations.NonNull Print print) {
            currentImage = print.getBitmap();
            // print can be a preview !
        }

        @Override
        public void onError(@io.reactivex.annotations.NonNull Throwable throwable) {
            //throwable can be a ResultException with some info on the kind of error
            if (throwable instanceof ResultException) {
                ResultException e = (ResultException) throwable;
            }
        }

        @Override
        public void onComplete() {
            //Capture is done
        }
    };
```

```java
reader.getFingerPrint()
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        //Close reader after calling observeOn so that is is closed on main thread after all operations are done.
        .doAfterTerminate(closeReader);
        .subscribe(fingerObserver);
```

[5]: ./wiki/img/device-2017-10-19-123936.gif
