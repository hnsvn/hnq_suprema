
void DHT11Read(void);
void dht_outputinit(void);
void dht_inputinit(void);
void dht_print(void);
void dht_LCDprint(void);