void stepping_sensor_init(void);
void stepper(int a);
void set_direction(void);