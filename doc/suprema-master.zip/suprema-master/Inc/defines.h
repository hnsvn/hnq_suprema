//------------------------------------
//defines.h file: (set by user)
//------------------------------------

//User wants to change that, use defines.h file like this:
#ifndef DEFINES_FILE
#define DEFINES_FILE

#define STM32F4xx
//Let's set EXTI NVIC preemption priority to highest, so we will do:
#define EXTI_NVIC_PRIORITY    0x00

#endif
