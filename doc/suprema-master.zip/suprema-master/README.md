# suprema
You are going to develop fingerprint module test board with ‘SFM6020’ and ‘SFM32F412ZGT’ board. SFM6020 is Suprema fingerprint module. SFM32F4 board is one of the opensource hardware boards. As following this instruction, you will put various components and sensors on the board to use functions of SFM 6020. 
